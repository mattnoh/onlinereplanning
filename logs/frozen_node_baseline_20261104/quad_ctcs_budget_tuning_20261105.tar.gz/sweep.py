import os,json,subprocess,pathlib,time
root=pathlib.Path('/tmp/comando-ctcs-budget-20261105')
base=json.load(open('/tmp/comando-fixed-dt-20261105/quad-rh-from-sh/final-profile.json'))
print(type(base),flush=True)
if 'SZMUK_N' not in base: raise RuntimeError(str(base)[:500])
binary='/tmp/comando-ordinary-node-rh-20261104/primary-planner/build/test_measured_root_rh'
results=[]
for eps,y in [(1e-5,9),(1e-5,11),(1e-5,6),(1e-5,7),(2e-5,10),(5e-5,10),(1e-4,10),(5e-6,10),(1e-5,.5),(2e-5,1),(5e-5,1),(1e-4,1)]:
 name=f'eps{eps:g}-y{y:g}';out=root/name
 env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','STC_','MPC_'))};env.update(base);env.update(SZMUK_CTCS_STEP_EPS=str(eps),SZMUK_CTCS_Y_SCALE=str(y))
 cmd=[binary,'quad','matched','40',str(out),'--audit-loop','--ctcs','--staging-initial']
 t=time.time()
 with open(str(out)+'.log','w') as f:
  try: rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120).returncode
  except subprocess.TimeoutExpired: rc=124
 summary=json.load(open(out/'summary.json')) if (out/'summary.json').exists() else {}
 record=dict(name=name,eps=eps,y=y,rc=rc,seconds=time.time()-t,summary=summary);results.append(record)
 (root/'results.json').write_text(json.dumps(results,indent=2))
 print(name,rc,{k:summary.get(k) for k in ['accepted','reached','native_ctcs_ratio','planned_ctcs_ratio','executed_ctcs_ratio','physical_stc_excess','planned_physical_stc_excess']},flush=True)
