import os,json,pathlib,subprocess,time
root=pathlib.Path('/tmp/comando-ctcs-budget-20261105/larger-dt');profile={}
for line in pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner/config/frozen_quad_ctcs.env').read_text().splitlines():
 if line.startswith('export '):k,v=line[7:].split('=',1);profile[k]=v
exe='/tmp/comando-ordinary-node-rh-20261104/primary-planner/build/test_measured_root_rh';results=[];winners=[]
# Epsilon scales with interval time first, preserving the nominal total horizon
# allowance. Nearby epsilon and conditioning/margin values are explicit trials.
settings=[(1,.5,.02),(1,1,.02),(1,10,.02),(.5,.5,.02),(2,.5,.02),(1,.5,.03),(.5,1,.03),(1,10,.03),(2,1,.02),(.25,.5,.03),(1,.1,.02),(1,5,.02)]
for N,K in [(40,2),(60,3)]:
 scale=80/N;won=False
 for idx,(eps_factor,y,geom) in enumerate(settings):
  env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','STC_','MPC_'))};env.update(profile);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',SZMUK_TEST_REPLAY_REPEATS='0')
  for key in ['SZMUK_TH0','SZMUK_THL','SZMUK_THH']:env[key]=str(float(profile[key])*scale)
  env.update(SZMUK_N=str(N),SZMUK_RH_N=str(N),SZMUK_CTCS_STEP_EPS=str(1e-5*scale*eps_factor),SZMUK_CTCS_Y_SCALE=str(y),SZMUK_CTCS_GEOMETRIC_MARGIN=str(geom))
  for mode in ['single','rh']:
   name=f'coarse-n{N}-t{idx}-{mode}';out=root/name;cmd=[exe,'quad','matched','1' if mode=='single' else '60',str(out),'--ctcs','--staging-initial','--audit-loop','--replay-intervals',str(K)]+(['--single-horizon'] if mode=='single' else [])
   t=time.time()
   with open(str(out)+'.log','w') as f:
    try:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120).returncode
    except subprocess.TimeoutExpired:rc=124
   summary=json.load(open(out/'summary.json')) if (out/'summary.json').exists() else None
   record=dict(name=name,N=N,K=K,scale=scale,trial_index=idx,mode=mode,returncode=rc,wall_seconds=time.time()-t,profile={k:v for k,v in env.items() if k.startswith('SZMUK_')},summary=summary,log_tail=pathlib.Path(str(out)+'.log').read_text()[-1800:]);results.append(record)
   (root/'coarse-results.json').write_text(json.dumps(results,indent=2));print(name,rc,{k:summary.get(k) for k in ['accepted','reached','native_ctcs_ratio','physical_stc_excess','planned_physical_stc_excess']} if summary else record['log_tail'][-220:],flush=True)
   if rc!=0:break
   if mode=='rh':winners.append(name);won=True
  if won:break
(root/'coarse-winners.json').write_text(json.dumps(winners));print('WINNERS',winners,flush=True)
