import os,json,pathlib,subprocess,time
root=pathlib.Path('/tmp/comando-ctcs-budget-20261105/larger-dt');prior=json.load(open(root/'coarse-results.json'));exe='/tmp/comando-ordinary-node-rh-20261104/primary-planner/build/test_measured_root_rh';results=[];winners=[]
trials=[('y.5',{'SZMUK_CTCS_Y_SCALE':'.5'}),('y1',{'SZMUK_CTCS_Y_SCALE':'1'}),('y2',{'SZMUK_CTCS_Y_SCALE':'2'}),('y3',{'SZMUK_CTCS_Y_SCALE':'3'}),('y4',{'SZMUK_CTCS_Y_SCALE':'4'}),('eps1e-5',{'SZMUK_CTCS_STEP_EPS':'1e-5'}),('rho50',{'SZMUK_RHO':'50','SZMUK_RHOT':'50'}),('rho10',{'SZMUK_RHO':'10','SZMUK_RHOT':'10'})]
for N,K,idx in [(60,3,11)]:
 selected=next(r['profile'] for r in json.load(open(root/'refine-results.json')) if r['name']=='refine-n60-rho30-single');won=False
 for tag,override in trials:
  env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','STC_','MPC_'))};env.update(selected);env.update(override);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
  for mode in ['single','rh']:
   name=f'budget-n{N}-{tag}-{mode}';out=root/name;cmd=[exe,'quad','matched','1' if mode=='single' else '60',str(out),'--ctcs','--staging-initial','--audit-loop','--replay-intervals',str(K)]+(['--single-horizon'] if mode=='single' else []);t=time.time()
   with open(str(out)+'.log','w') as f:
    try:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120).returncode
    except subprocess.TimeoutExpired:rc=124
   summary=json.load(open(out/'summary.json')) if (out/'summary.json').exists() else None
   r=dict(name=name,N=N,K=K,mode=mode,returncode=rc,wall_seconds=time.time()-t,profile={k:v for k,v in env.items() if k.startswith('SZMUK_')},summary=summary,log_tail=pathlib.Path(str(out)+'.log').read_text()[-1800:]);results.append(r);(root/'coarse-budget-results.json').write_text(json.dumps(results,indent=2))
   print(name,rc,{k:summary.get(k) for k in ['accepted','reached','native_ctcs_ratio','physical_stc_excess','planned_physical_stc_excess']} if summary else r['log_tail'][-220:],flush=True)
   if rc!=0:break
   if mode=='rh':won=True;winners.append(name)
  # Complete budget comparisons even after physical passes.
(root/'coarse-budget-winners.json').write_text(json.dumps(winners));print('WINNERS',winners,flush=True)
