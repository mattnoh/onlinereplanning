import os,json,pathlib,subprocess,time
root=pathlib.Path('/tmp/comando-ctcs-budget-20261105/larger-dt');prior=json.load(open(root/'coarse-results.json'));exe='/tmp/comando-ordinary-node-rh-20261104/primary-planner/build/test_measured_root_rh';results=[];winners=[]
trials=[('term2',{'SZMUK_TERM_W_POS_XY':'200000','SZMUK_TERM_W_POS_Z':'20000'}),('term5',{'SZMUK_TERM_W_POS_XY':'500000','SZMUK_TERM_W_POS_Z':'50000'}),('term.5',{'SZMUK_TERM_W_POS_XY':'50000','SZMUK_TERM_W_POS_Z':'5000'}),('z10',{'SZMUK_TERM_W_POS_Z':'100000'}),('geom.025',{'SZMUK_CTCS_GEOMETRIC_MARGIN':'.025'}),('geom.015',{'SZMUK_CTCS_GEOMETRIC_MARGIN':'.015'}),('reg.2',{'SZMUK_REG2_MIN':'.2'}),('reg.05',{'SZMUK_REG2_MIN':'.05'}),('mu.05',{'SZMUK_MU':'.05','SZMUK_MUT':'.05'}),('rho30',{'SZMUK_RHO':'30','SZMUK_RHOT':'30'}),('rho300',{'SZMUK_RHO':'300','SZMUK_RHOT':'300'}),('mu.2',{'SZMUK_MU':'.2','SZMUK_MUT':'.2'})]
for N,K,idx in [(60,3,11),(40,2,3)]:
 selected=next(r['profile'] for r in prior if r['name']==f'coarse-n{N}-t{idx}-single');won=False
 for tag,override in trials:
  env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','STC_','MPC_'))};env.update(selected);env.update(override);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
  for mode in ['single','rh']:
   name=f'refine-n{N}-{tag}-{mode}';out=root/name;cmd=[exe,'quad','matched','1' if mode=='single' else '60',str(out),'--ctcs','--staging-initial','--audit-loop','--replay-intervals',str(K)]+(['--single-horizon'] if mode=='single' else []);t=time.time()
   with open(str(out)+'.log','w') as f:
    try:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120).returncode
    except subprocess.TimeoutExpired:rc=124
   summary=json.load(open(out/'summary.json')) if (out/'summary.json').exists() else None
   r=dict(name=name,N=N,K=K,mode=mode,returncode=rc,wall_seconds=time.time()-t,profile={k:v for k,v in env.items() if k.startswith('SZMUK_')},summary=summary,log_tail=pathlib.Path(str(out)+'.log').read_text()[-1800:]);results.append(r);(root/'refine-results.json').write_text(json.dumps(results,indent=2))
   print(name,rc,{k:summary.get(k) for k in ['accepted','reached','native_ctcs_ratio','physical_stc_excess','planned_physical_stc_excess']} if summary else r['log_tail'][-220:],flush=True)
   if rc!=0:break
   if mode=='rh':won=True;winners.append(name)
  if won:break
(root/'refine-winners.json').write_text(json.dumps(winners));print('WINNERS',winners,flush=True)
