import json,pathlib,hashlib,subprocess,tarfile,copy
repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');root=pathlib.Path('/tmp/comando-ctcs-budget-20261105')
val=json.load(open(root/'selected-validation.json'));rh=val['selected-rh']['summary'];assert all(v['returncode']==0 for v in val.values())
def rows(path):
 lines=path.read_text().splitlines();d={}
 for i,line in enumerate(lines):
  a=line.split()
  if a and a[0] in ['prepared_X','prepared_U','returned_X','returned_U']:d[a[0]]=[[float(v) for v in l.split()] for l in lines[i+1:i+1+int(a[1])]]
 return d
sh=rows(root/'selected-single/request-0.txt');first=rows(root/'selected-rh/request-0.txt');parity={k:max(abs(a-b) for x,y in zip(sh[k],first[k]) for a,b in zip(x,y)) for k in sh};assert all(v==0 for v in parity.values());(root/'first-request-parity.json').write_text(json.dumps(parity,indent=2))
for f,h in json.load(open('/tmp/comando-ordinary-node-rh-20261104/primary-planner/protected-files.json')).items():assert hashlib.sha256((repo/f).read_bytes()).hexdigest()==h,f
assert not subprocess.check_output(['git','-C',str(repo.parent/'ALIPDDP-main'),'diff','--name-only','002850df','--','alipddp','problem_maker'])
assert not subprocess.check_output(['git','-C',str(repo),'diff','477dfba','--','include','src','support/test/test_measured_root_rh.cpp'])
archive=repo/'logs/frozen_node_baseline_20261104/quad_ctcs_budget_tuning_20261105.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(root.iterdir()):tar.add(p,arcname=p.name)
trials=[]
for f in ['results.json','accuracy-results.json','local-results.json']:trials+=json.load(open(root/f))
assert len(trials)==30
budget=rh['physical_interval_budget'];overshoot=rh['native_ctcs_ratio']-1
selected=dict(planner_config_commit='26339b31b81fb5745f06c032a902942fb41c8da7',status='Native budget excess reduced, not eliminated; original physical audits pass on the scoped frozen moving-target root.',allowance_unchanged=budget,selected_y_scale=0.5,before_y_scale=10,before_native_budget_ratio=1.0032497284982316,after_native_budget_ratio=rh['native_ctcs_ratio'],native_overspend_percent=100*overshoot,physical_integral_overspend=budget*overshoot,improvement_factor=(1.0032497284982316-1)/overshoot,strict_raw_native_budget_met=False,independent_integral_budget_met=False,independent_planned_integral_ratio=rh['planned_ctcs_ratio'],independent_executed_integral_ratio=rh['executed_ctcs_ratio'],acceptance_checks_unchanged=True,solver_and_rh_loop_unchanged=True,tuning_trials=trials,validation=val,paired_SH_first_RH=parity,retained_archive=str(archive.relative_to(repo)),source_profile_sha256=hashlib.sha256((repo/'config/frozen_quad_ctcs.env').read_bytes()).hexdigest(),scope='Same staging-hover moving-target root, K4, N80, frozen solve time, matched plant. No general IC/realtime claim.',rejected_changes='No source changes or other parameter changes retained. Tighter tolerance, alternate epsilon, scale, rho, mu and mu_mul trials recorded; no strict native+physical pass found.')
p=repo/'logs/frozen_node_baseline_20261104/quad_ctcs_rh_from_sh_20261105.json';d=json.load(open(p));d['budget_tuning']=selected;d['status']='Scoped physical pass; budget tuning reduces native excess to 8.83e-12 physical integral units but strict budget remains unresolved. Original validation fields describe the preceding Y10 profile; budget_tuning contains current Y0.5 validation.';p.write_text(json.dumps(d,indent=2)+'\n')
p=repo/'support/test/frozen_node_baseline.json';d=json.load(open(p));cur=d['current_quad_ctcs_rh_case'];cur['previous_Y10_validation']=dict(summary=copy.deepcopy(cur['summary']),known_limits=copy.deepcopy(cur['known_limits']),planner_code_commit=cur['planner_code_commit']);cur['planner_code_commit']=selected['planner_config_commit'];cur['summary']=rh;cur['retained_changes']=[v.replace('Y scale 10','Y scale 0.5') for v in cur['retained_changes']];cur['known_limits'].update(max_native_row_residual=rh['native_violation'],native_budget_ratio=rh['native_ctcs_ratio'],raw_native_budget_overspend_percent=100*overshoot,independent_planned_integral_ratio=rh['planned_ctcs_ratio'],independent_executed_integral_ratio=rh['executed_ctcs_ratio'],tested_stationary_target_hover_and_inbound_near_cold_starts='The preceding Y10 profile failed some roots. Broader cold-start coverage of the tuned Y0.5 profile is not established.');cur['budget_tuning_summary']={k:v for k,v in selected.items() if k not in ['tuning_trials','validation']};d['verified_planner_code_commit']=selected['planner_config_commit'];p.write_text(json.dumps(d,indent=2)+'\n')
p=repo/'README.md';s=p.read_text();s=s.replace('It completes 19 replans / 7.73931 simulated','It completes 20 replans / 7.73252 simulated').replace('physical excess 8.05439e-7','physical excess 8.13919e-7');a=s.index('maximum native row residual is 3.24973e-9');b=s.index('The literal physical checks',a)
s=s[:a]+'''maximum native row residual is 1.76514e-11, below native tolerance 1e-6. A
30-case budget/conditioning sweep retained equivalent row scaling Y=0.5 instead
of 10; the physical budget remains 1e-5. Native budget ratio fell from
1.00324973 to 1.00000088257 (0.0000883% overspend, or 8.83e-12 physical integral
units). This is a 3682-fold reduction, not strict-zero budget satisfaction.
Independent refined ratios remain 1.85482 planned / 1.00443 executed; they are
diagnostics and do not constitute a passing finer-integral certificate. Both
the full single-horizon check and a fresh RH repeat pass with the selected
profile; first-request prepared/returned trajectories are identical. The
preceding Y10 profile failed some stationary-hover, inbound and near-center
cold starts; broader coverage with Y0.5 remains unestablished.
'''+s[b:];s=s.replace('passed raw runs are retained alongside it as a `.tar.gz` archive.','passed raw runs are retained alongside it as a `.tar.gz` archive. The later\n30-case tuning sweep and selected single/RH runs are retained in\n`quad_ctcs_budget_tuning_20261105.tar.gz` alongside that record.');p.write_text(s)
print('Trials',len(trials),'parity',parity,'improvement',selected['improvement_factor'],'archive bytes',archive.stat().st_size)
