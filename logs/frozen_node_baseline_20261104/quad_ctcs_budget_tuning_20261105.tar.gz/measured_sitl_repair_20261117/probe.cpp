#include "planner_core/types.hpp"
#include <fstream>
#include <iostream>
#include <iomanip>
int main(int argc,char**argv){
 std::ifstream f(argv[1]);int count;f>>count;auto desc=OCPRegistry::getDescriptor("stc_landing_noaug");auto model=desc.make_model(Eigen::Vector3d::Zero());
 std::cout<<std::setprecision(10);
 for(int c=0;c<count;++c){std::string tag;double age,activation;int N;f>>tag>>age>>activation>>N;Eigen::VectorXd x=Eigen::VectorXd::Zero(14),truth=x;Eigen::Vector3d acc,relative_offset,relative_velocity;
  for(int j=0;j<13;++j)f>>x(j);for(int j=0;j<13;++j)f>>truth(j);for(int j=0;j<3;++j)f>>acc(j);for(int j=0;j<3;++j)f>>relative_offset(j);for(int j=0;j<3;++j)f>>relative_velocity(j);
  std::vector<double> t(N+1);std::vector<Eigen::VectorXd> u(N);for(auto& v:t)f>>v;for(auto& v:u){v.resize(5);for(int j=0;j<5;++j)f>>v(j);}
  auto initial=x;for(double s=age;s<activation-1e-10;){double h=std::min(.001,activation-s);auto control=model.hover;if(s>=0){int k=std::upper_bound(t.begin(),t.end(),s)-t.begin()-1;k=std::clamp(k,0,N-1);control=u[k];}x=model.flow(x,control,h,false).x;s+=h;}
  Eigen::Quaterniond qa(x(6),x(7),x(8),x(9)),qb(truth(6),truth(7),truth(8),truth(9));std::cout<<"ROOT "<<tag<<" position_error "<<(x.head(3)-truth.head(3)).norm()<<" velocity_error "<<(x.segment(3,3)-truth.segment(3,3)).norm()<<" angle_error_deg "<<qa.angularDistance(qb)*180/M_PI<<" rate_error "<<(x.segment(10,3)-truth.segment(10,3)).norm()<<"\n";
  for(int guess=0;guess<2;++guess){OCPCreateArgs args;args.current_state=x;args.current_state.head<3>()-=relative_offset;args.current_state.segment<3>(3)-=relative_velocity;args.target_accel=acc;
   if(guess){int shift=std::lower_bound(t.begin(),t.end(),activation-1e-8)-t.begin();for(int k=0;k<N;++k)args.prev_U.push_back(u[std::min(k+shift,N-1)]);}
   auto p=desc.create(args);auto params=desc.getSolverParams();params.verbose=false;ALIPDDP<double> solver(*p);solver.init(params);solver.solve();auto X=solver.getResX();auto U=solver.getResU();double excess=0;for(int k=0;k<N;++k)for(auto type:{ConstraintType::NO,ConstraintType::SOC,ConstraintType::EQ})for(auto& row:p->getStageConstraints(k,type)){auto r=row->c(X[k],U[k]);double v=type==ConstraintType::NO?r.maxCoeff():type==ConstraintType::SOC?r(0)+r.tail(r.size()-1).norm():r.cwiseAbs().maxCoeff();excess=std::max(excess,v);}
   std::cout<<"SOLVE "<<tag<<" guess "<<(guess?"shifted":"native")<<" primal "<<excess<<" error "<<solver.getError()<<" iterations "<<solver.getNumIter()<<std::endl;
  }
 }
}
