import os,json,pathlib,subprocess
repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');out=pathlib.Path(__file__).resolve().parent;base={}
for l in (repo/'config/frozen_quad_ctcs_coarse.env').read_text().splitlines():
 if l.startswith('export '):k,v=l[7:].split('=',1);base[k]=v
base['SZMUK_CTCS_LOS_MARGIN']='.035'
base['SZMUK_CTCS_TILT_MARGIN_DEG']='.005'
base['SZMUK_W_STC_LOS']='1000'
trials=[('los1000-tilt0',{'SZMUK_CTCS_TILT_MARGIN_DEG':'0'}),('los1000-tilt01',{'SZMUK_CTCS_TILT_MARGIN_DEG':'.01'}),('los1000-budget5e6',{'SZMUK_CTCS_STEP_EPS':'5e-6'}),('los1000-budget1e6',{'SZMUK_CTCS_STEP_EPS':'1e-6'}),('los1000-y2',{'SZMUK_CTCS_Y_SCALE':'2'}),('los1000-y10',{'SZMUK_CTCS_Y_SCALE':'10'}),('los2000',{'SZMUK_W_STC_LOS':'2000'}),('los500',{'SZMUK_W_STC_LOS':'500'})]
results=[]
for tag,over in trials:
 env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','MPC_','STC_','WALL_RH_'))};env.update(base);env.update(over);log=out/('turn-gate-'+tag+'.log')
 with log.open('w') as f:
  try:rc=subprocess.run(['/home/lab/mavros_ws/build/comando_planner/test_stc_landing_noaug_ctcs','--turning-horizon'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30).returncode
  except subprocess.TimeoutExpired:rc=124
 result={'tag':tag,'overrides':over,'returncode':rc,'output':log.read_text()};results.append(result);(out/'turn-refined-gates.json').write_text(json.dumps(results,indent=2)+'\n');print(tag,rc,log.read_text().splitlines()[-2:],flush=True)
