import os,json,pathlib,subprocess
repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');out=pathlib.Path(__file__).resolve().parent;base={}
for l in (repo/'config/frozen_quad_ctcs_coarse.env').read_text().splitlines():
 if l.startswith('export '):k,v=l[7:].split('=',1);base[k]=v
base['SZMUK_CTCS_LOS_MARGIN']='.035'
base['SZMUK_CTCS_TILT_MARGIN_DEG']='.005'
trials=[('filter0',{'SZMUK_FORWARD_FILTER':'0'}),('reg01',{'SZMUK_REG2_MIN':'.01'}),('reg001',{'SZMUK_REG2_MIN':'.001'}),('reg10',{'SZMUK_REG2_MIN':'10'}),('y02',{'SZMUK_CTCS_Y_SCALE':'.2'}),('y05',{'SZMUK_CTCS_Y_SCALE':'.5'}),('eps1e3',{'SZMUK_CTCS_STEP_EPS':'.001'}),('th16',{'SZMUK_THH':'.2','SZMUK_TH0':'.12'}),('filter0y2',{'SZMUK_FORWARD_FILTER':'0','SZMUK_CTCS_Y_SCALE':'2'}),('tol1e7',{'SZMUK_TOL':'1e-7'}),('rho1',{'SZMUK_RHO':'1','SZMUK_RHOT':'1'}),('y20',{'SZMUK_CTCS_Y_SCALE':'20'})]
results=[]
for tag,over in trials:
 env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','MPC_','STC_','WALL_RH_'))};env.update(base);env.update(over);log=out/('turn-gate-'+tag+'.log')
 with log.open('w') as f:
  try:rc=subprocess.run(['/home/lab/mavros_ws/build/comando_planner/test_stc_landing_noaug_ctcs','--turning-horizon'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30).returncode
  except subprocess.TimeoutExpired:rc=124
 result={'tag':tag,'overrides':over,'returncode':rc,'output':log.read_text()};results.append(result);(out/'turn-numerical-gates.json').write_text(json.dumps(results,indent=2)+'\n');print(tag,rc,log.read_text().splitlines()[-2:],flush=True)
