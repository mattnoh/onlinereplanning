import csv,importlib.util,pathlib,numpy as np
repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');s=importlib.util.spec_from_file_location('score',repo/'support/scripts/mc_physical_scoring.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
f=open('/tmp/comando-sitl-repair-20261110/probes.txt','w');cases=[]
for mode in ['stationary','']:
 cell=pathlib.Path('/tmp/comando-measured-rh-sitl-20261109')/mode/'circle__zero__t0';d,t,gt,logs=m.read_bag(next(cell.glob('flight_*.bag')));events=list(csv.DictReader((cell/'solver_events.csv').open()));acc=[r for r in events if r['event']=='accepted'];offset=next(ts for ts,msg in logs if '[solve_accepted]' in msg)-float(acc[0]['timestamp']);rows=list(csv.DictReader((cell/'all_solves.csv').open()));seen=set()
 for e in events:
  if e['event']!='rejected' or int(e['solve_num'])<=0 or e['solve_num'] in seen:continue
  seen.add(e['solve_num']);prior=int(e['solve_num'])-1;p=[r for r in rows if int(r['solve_num'])==prior];N=len(p)-1;age=float(e['active_elapsed_now_sec']);activation=float(e['activation_elapsed_sec']);origin=float(e['activation_wall_time_sec'])-activation;measurement=origin+age+offset;handoff=origin+activation+offset
  vector=lambda a,epoch: [float(np.interp(epoch,a[:,0],a[:,k])) for k in range(1,a.shape[1])]
  u=[[float(r[k]) for k in ['fz','mx','my','mz','theta']] for r in p[:-1]];acceleration=np.array([float(p[0]['tgt_'+k]) for k in ['ax','ay','az']]);target=np.array(vector(t,measurement));delay=activation-age;pos=target[:3]+target[3:]*delay+.5*acceleration*delay**2;vel=target[3:]+acceleration*delay
  case=[f'{mode or "circle"}-{e["solve_num"]} {age} {activation} {N}',' '.join(map(str,vector(d,measurement))),' '.join(map(str,vector(d,handoff))),' '.join(map(str,acceleration)),' '.join(map(str,pos)),' '.join(map(str,vel)),' '.join(r['t'] for r in p)]+[' '.join(map(str,x)) for x in u];cases.append('\n'.join(case))
f.write(str(len(cases))+'\n'+'\n'.join(cases)+'\n');f.close();print('cases',len(cases))
