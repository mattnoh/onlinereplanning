import os,json,pathlib,subprocess
repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');out=pathlib.Path(__file__).resolve().parent;base={}
for l in (repo/'config/frozen_quad_ctcs_coarse.env').read_text().splitlines():
 if l.startswith('export '):k,v=l[7:].split('=',1);base[k]=v
base['SZMUK_CTCS_LOS_MARGIN']='.035'
base['SZMUK_CTCS_TILT_MARGIN_DEG']='.005'
trials=[('tiltw1e7',{'SZMUK_W_LAND_TILT':'1e7'}),('tiltw1e6',{'SZMUK_W_LAND_TILT':'1e6'}),('tiltw1e9',{'SZMUK_W_LAND_TILT':'1e9'}),('momreg10',{'SZMUK_REG2_MIN':'100'}),('wlos50',{'SZMUK_W_STC_LOS':'50'}),('wlos1000',{'SZMUK_W_STC_LOS':'1000'}),('g02',{'SZMUK_CTCS_LOS_MARGIN':'.02'}),('termz1e5',{'SZMUK_TERM_W_POS_Z':'100000'}),('termxy1e4',{'SZMUK_TERM_W_POS_XY':'10000'}),('stagecost',{'SZMUK_W_POS_XY':'1','SZMUK_W_POS_Z':'1'}),('y100',{'SZMUK_CTCS_Y_SCALE':'100'}),('eps1e4',{'SZMUK_CTCS_STEP_EPS':'.0001'})]
results=[]
for tag,over in trials:
 env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','MPC_','STC_','WALL_RH_'))};env.update(base);env.update(over);log=out/('turn-gate-'+tag+'.log')
 with log.open('w') as f:
  try:rc=subprocess.run(['/home/lab/mavros_ws/build/comando_planner/test_stc_landing_noaug_ctcs','--turning-horizon'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30).returncode
  except subprocess.TimeoutExpired:rc=124
 result={'tag':tag,'overrides':over,'returncode':rc,'output':log.read_text()};results.append(result);(out/'turn-weight-gates.json').write_text(json.dumps(results,indent=2)+'\n');print(tag,rc,log.read_text().splitlines()[-2:],flush=True)
