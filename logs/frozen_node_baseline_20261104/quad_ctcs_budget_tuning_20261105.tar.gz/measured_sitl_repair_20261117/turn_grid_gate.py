import os,json,pathlib,subprocess
repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');out=pathlib.Path(__file__).resolve().parent;base={}
for l in (repo/'config/frozen_quad_ctcs_coarse.env').read_text().splitlines():
 if l.startswith('export '):k,v=l[7:].split('=',1);base[k]=v
base['SZMUK_CTCS_LOS_MARGIN']='.035'
base['SZMUK_CTCS_TILT_MARGIN_DEG']='.005'
base['SZMUK_W_STC_LOS']='1000'
trials=[('n40',{'SZMUK_N':'40','SZMUK_RH_N':'40','SZMUK_TH0':'.14','SZMUK_THL':'.1','SZMUK_THH':'.24'}),('n100',{'SZMUK_N':'100','SZMUK_RH_N':'100','SZMUK_TH0':'.056','SZMUK_THL':'.04','SZMUK_THH':'.096'}),('n120',{'SZMUK_N':'120','SZMUK_RH_N':'120','SZMUK_TH0':'.0466666666666667','SZMUK_THL':'.0333333333333333','SZMUK_THH':'.08'}),('n60short',{'SZMUK_TH0':'.07','SZMUK_THL':'.04','SZMUK_THH':'.12'}),('n60long',{'SZMUK_TH0':'.14','SZMUK_THL':'.07','SZMUK_THH':'.2'})]
results=[]
for tag,over in trials:
 env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','MPC_','STC_','WALL_RH_'))};env.update(base);env.update(over);log=out/('turn-gate-'+tag+'.log')
 with log.open('w') as f:
  try:rc=subprocess.run(['/home/lab/mavros_ws/build/comando_planner/test_stc_landing_noaug_ctcs','--turning-horizon'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30).returncode
  except subprocess.TimeoutExpired:rc=124
 result={'tag':tag,'overrides':over,'returncode':rc,'output':log.read_text()};results.append(result);(out/'turn-grid-gates.json').write_text(json.dumps(results,indent=2)+'\n');print(tag,rc,log.read_text().splitlines()[-2:],flush=True)
