from pathlib import Path
import hashlib,io,json,os,tarfile,tempfile
root=Path(__file__).resolve().parent;repo=Path('/home/lab/mavros_ws/src/CoManDO_planner');dest=repo/'logs/frozen_node_baseline_20261104/quad_ctcs_budget_tuning_20261105.tar.gz';prefix='measured_sitl_repair_20261117';old_bytes=dest.stat().st_size;hashes={}
with tempfile.NamedTemporaryFile(prefix='comando-sitl-evidence-',suffix='.tar.gz',dir=dest.parent,delete=False) as f:new=Path(f.name)
try:
 with tarfile.open(dest,'r:gz') as src,tarfile.open(new,'w:gz',compresslevel=6) as out:
  for member in src:
   assert not member.name.startswith(prefix+'/'),'already archived; do not duplicate'
   data=src.extractfile(member).read() if member.isfile() else None
   if data is not None:hashes[member.name]=hashlib.sha256(data).hexdigest()
   out.addfile(member,io.BytesIO(data) if data is not None else None)
  keep=set()
  for p in root.iterdir():
   if p.is_file() and p.suffix in ['.json','.py','.patch','.log','.txt','.cpp']:keep.add(p)
  for case in root.iterdir():
   if not case.is_dir() or not (case/'configuration.json').exists():continue
   for p in case.iterdir():
    if p.is_file() and p.suffix in ['.json','.py','.yaml','.params','.log']:keep.add(p)
   cell=case/'circle__zero__t0'
   if not cell.exists():continue
   for p in cell.iterdir():
    if p.is_file() and p.suffix in ['.json','.csv','.yaml','.bag','.log']:keep.add(p)
  # Include full-horizon gate results/requests without compiler binaries.
  for folder in root.iterdir():
   if folder.is_dir() and folder.name.endswith('-single'):
    for p in folder.rglob('*'):
     if p.is_file() and p.suffix in ['.json','.jsonl','.csv','.txt']:keep.add(p)
  for p in sorted(keep):out.add(p,arcname=prefix+'/'+str(p.relative_to(root)))
 with tarfile.open(new,'r:gz') as check:
  for member in check:
   if member.name in hashes:
    assert hashlib.sha256(check.extractfile(member).read()).hexdigest()==hashes.pop(member.name),member.name
 assert not hashes
 os.replace(new,dest)
 print(json.dumps({'old_bytes':old_bytes,'new_bytes':dest.stat().st_size,'prior_entries_preserved':True,'added_files':len(keep)}))
finally:
 if new.exists():new.unlink()
