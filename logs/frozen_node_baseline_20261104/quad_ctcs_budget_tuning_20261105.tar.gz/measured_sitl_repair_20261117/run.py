import contextlib,pathlib,runpy,sys
root=pathlib.Path(__file__).resolve().parent
case=(root/sys.argv[1]).resolve()
assert case.parent==root
if len(sys.argv)>2 and sys.argv[2]=='--stop':
 import os,signal,subprocess
 query=subprocess.run(['pgrep','-f','^python3 '+str(root/'run.py')+' '+sys.argv[1]+'$'],capture_output=True,text=True)
 for pid in query.stdout.split():os.kill(int(pid),signal.SIGINT)
 sys.exit(0)
if len(sys.argv)>2 and sys.argv[2]=='--params':
 import os,json,subprocess
 os.environ['ROS_MASTER_URI']=json.loads((case/'configuration.json').read_text())['ros_master'];os.environ['ROS_IP']='127.0.0.1'
 with (case/'param-query.log').open('w') as log:
  result=subprocess.run(['bash','-lc','source /opt/ros/noetic/setup.bash && source /home/lab/mavros_ws/devel/setup.bash && rosrun mavros mavparam dump -f '+str(case/'px4-live.params')],stdout=log,stderr=subprocess.STDOUT,timeout=50)
 sys.exit(result.returncode)
with (case/'run.log').open('w',buffering=1) as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):runpy.run_path(str(case/'run.py'),run_name='__main__')
