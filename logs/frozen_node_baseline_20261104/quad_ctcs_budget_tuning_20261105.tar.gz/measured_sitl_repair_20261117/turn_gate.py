import os,json,pathlib,subprocess
repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');out=pathlib.Path(__file__).resolve().parent;base={}
for l in (repo/'config/frozen_quad_ctcs_coarse.env').read_text().splitlines():
 if l.startswith('export '):k,v=l[7:].split('=',1);base[k]=v
base['SZMUK_CTCS_LOS_MARGIN']='.035'
trials=[('y2',{'SZMUK_CTCS_Y_SCALE':'2'}),('y1',{'SZMUK_CTCS_Y_SCALE':'1'}),('rho100',{'SZMUK_RHO':'100','SZMUK_RHOT':'100'}),('reg1',{'SZMUK_REG2_MIN':'1'}),('xy2',{'SZMUK_TERM_W_POS_XY':'200000'}),('rho10',{'SZMUK_RHO':'10','SZMUK_RHOT':'10'}),('mu01',{'SZMUK_MU':'.01','SZMUK_MUT':'.01'}),('y10',{'SZMUK_CTCS_Y_SCALE':'10'}),('eps2',{'SZMUK_CTCS_STEP_EPS':'2e-5'}),('eps5',{'SZMUK_CTCS_STEP_EPS':'5e-5'})]
results=[]
for tag,over in trials:
 env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','MPC_','STC_','WALL_RH_'))};env.update(base);env.update(over);log=out/('turn-gate-'+tag+'.log')
 with log.open('w') as f:
  try:rc=subprocess.run(['/home/lab/mavros_ws/build/comando_planner/test_stc_landing_noaug_ctcs','--turning-horizon'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30).returncode
  except subprocess.TimeoutExpired:rc=124
 result={'tag':tag,'overrides':over,'returncode':rc,'output':log.read_text()};results.append(result);(out/'turn-gates.json').write_text(json.dumps(results,indent=2)+'\n');print(tag,rc,log.read_text().splitlines()[-2:],flush=True)
