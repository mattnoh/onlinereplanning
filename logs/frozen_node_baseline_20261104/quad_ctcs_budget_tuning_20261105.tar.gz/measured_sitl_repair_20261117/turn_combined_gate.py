import os,json,pathlib,subprocess
repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');out=pathlib.Path(__file__).resolve().parent;base={}
for l in (repo/'config/frozen_quad_ctcs_coarse.env').read_text().splitlines():
 if l.startswith('export '):k,v=l[7:].split('=',1);base[k]=v
base['SZMUK_CTCS_LOS_MARGIN']='.035'
base['SZMUK_CTCS_TILT_MARGIN_DEG']='.005'
base['SZMUK_W_STC_LOS']='1000'
base['SZMUK_CTCS_TILT_MARGIN_DEG']='0'
trials=[('tilt0rate007',{'SZMUK_CTCS_RATE_MARGIN':'.007'}),('tilt0rate003',{'SZMUK_CTCS_RATE_MARGIN':'.003'}),('tilt0omega1e7',{'SZMUK_W_LAND_OMEGA':'1e7'}),('tilt0losmargin04',{'SZMUK_CTCS_LOS_MARGIN':'.04'}),('tilt0losmargin045',{'SZMUK_CTCS_LOS_MARGIN':'.045'}),('tilt0g0',{'SZMUK_CTCS_GEOMETRIC_MARGIN':'0'}),('tilt0eps1e5',{'SZMUK_CTCS_STEP_EPS':'1e-5'}),('tilt0eps2e5',{'SZMUK_CTCS_STEP_EPS':'2e-5'}),('tilt0tiltw1e9',{'SZMUK_W_LAND_TILT':'1e9'}),('tilt0reg1',{'SZMUK_REG2_MIN':'1'})]
results=[]
for tag,over in trials:
 env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','MPC_','STC_','WALL_RH_'))};env.update(base);env.update(over);log=out/('turn-gate-'+tag+'.log')
 with log.open('w') as f:
  try:rc=subprocess.run(['/home/lab/mavros_ws/build/comando_planner/test_stc_landing_noaug_ctcs','--turning-horizon'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30).returncode
  except subprocess.TimeoutExpired:rc=124
 result={'tag':tag,'overrides':over,'returncode':rc,'output':log.read_text()};results.append(result);(out/'turn-combined-gates.json').write_text(json.dumps(results,indent=2)+'\n');print(tag,rc,log.read_text().splitlines()[-2:],flush=True)
