import csv,importlib.util,pathlib,numpy as np
from scipy.linalg import expm
from scipy.spatial.transform import Rotation
repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');s=importlib.util.spec_from_file_location('score',repo/'support/scripts/mc_physical_scoring.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
for mode in ['stationary','']:
 cell=pathlib.Path('/tmp/comando-measured-rh-sitl-20261109')/mode/'circle__zero__t0';d,t,gt,logs=m.read_bag(next(cell.glob('flight_*.bag')));events=list(csv.DictReader((cell/'solver_events.csv').open()));acc=[r for r in events if r['event']=='accepted'];offset=next(ts for ts,msg in logs if '[solve_accepted]' in msg)-float(acc[0]['timestamp']);rows=list(csv.DictReader((cell/'all_solves.csv').open()));seen=set()
 for e in events:
  if e['event']!='rejected' or int(e['solve_num'])<=0 or e['solve_num'] in seen:continue
  seen.add(e['solve_num']);prior=int(e['solve_num'])-1;p=[r for r in rows if int(r['solve_num'])==prior];times=np.array([float(r['t']) for r in p]);age=float(e['active_elapsed_now_sec']);activation=float(e['activation_elapsed_sec']);origin=float(e['activation_wall_time_sec'])-activation;measurement=origin+age+offset;handoff=origin+activation+offset
  interp=lambda a,epoch: np.array([np.interp(epoch,a[:,0],a[:,k]) for k in range(1,a.shape[1])])
  nominal=np.array([[float(r[k]) for k in ['px','py','pz','vx','vy','vz','qw','qx','qy','qz','wx','wy','wz']] for r in p]);nominal[:,:6]+=np.array([[float(r['tgt_'+k]) for k in ['x','y','z','vx','vy','vz']] for r in p])
  now=np.array([np.interp(age,times,nominal[:,k]) for k in range(13)]);future=np.array([np.interp(activation,times,nominal[:,k]) for k in range(13)]);live=interp(d,measurement);truth=interp(d,handoff);delta=activation-age;pred=future.copy()
  for j,(kp,kv) in enumerate([(0.95,1.8/1.2),(0.95,1.8/1.2),(1.,4.)]):
   err=expm(np.array([[0.,1.],[-kv*kp,-kv]])*delta)@np.array([live[j]-now[j],live[j+3]-now[j+3]]);pred[j]+=err[0];pred[j+3]+=err[1]
  rot=lambda x:Rotation.from_quat(x[[7,8,9,6]])
  theta=(rot(now).inv()*rot(live)).as_rotvec();omega=live[10:13]-now[10:13];ef=np.zeros((2,3))
  for j,g in enumerate([4.,4.,2.8]):ef[:,j]=expm(np.array([[0.,1.],[-g/.08,-1/.08]])*delta)@np.array([theta[j],omega[j]])
  qp=(rot(future)*Rotation.from_rotvec(ef[0])).as_quat();pred[6:10]=qp[[3,0,1,2]];pred[10:13]+=ef[1]
  print(mode or 'circle',e['solve_num'],'position',np.linalg.norm(pred[:3]-truth[:3]),'velocity',np.linalg.norm(pred[3:6]-truth[3:6]),'angle',np.linalg.norm((rot(pred).inv()*rot(truth)).as_rotvec())*180/np.pi,'rate',np.linalg.norm(pred[10:13]-truth[10:13]))
