import os,json,pathlib,subprocess
repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');out=pathlib.Path(__file__).resolve().parent;base={}
for l in (repo/'config/frozen_quad_ctcs_coarse.env').read_text().splitlines():
 if l.startswith('export '):k,v=l[7:].split('=',1);base[k]=v
base['SZMUK_CTCS_LOS_MARGIN']='.035'
base['SZMUK_CTCS_TILT_MARGIN_DEG']='.005'
base['SZMUK_W_STC_LOS']='1000'
trials=[('los1000-rate01',{'SZMUK_CTCS_RATE_MARGIN':'.01'}),('los1000-omega1e8',{'SZMUK_W_LAND_OMEGA':'1e8'}),('los1000-omega1e7',{'SZMUK_W_LAND_OMEGA':'1e7'}),('los1000-geom05',{'SZMUK_CTCS_LOS_MARGIN':'.05'}),('los1000-rate01geom05',{'SZMUK_CTCS_RATE_MARGIN':'.01','SZMUK_CTCS_LOS_MARGIN':'.05'}),('los1000-omega1e7geom05',{'SZMUK_W_LAND_OMEGA':'1e7','SZMUK_CTCS_LOS_MARGIN':'.05'}),('los1000-omega1e7tilt1e9',{'SZMUK_W_LAND_OMEGA':'1e7','SZMUK_W_LAND_TILT':'1e9'}),('los1000-margins',{'SZMUK_CTCS_RATE_MARGIN':'.008','SZMUK_CTCS_LOS_MARGIN':'.045','SZMUK_CTCS_TILT_MARGIN_DEG':'.01'})]
results=[]
for tag,over in trials:
 env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','MPC_','STC_','WALL_RH_'))};env.update(base);env.update(over);log=out/('turn-gate-'+tag+'.log')
 with log.open('w') as f:
  try:rc=subprocess.run(['/home/lab/mavros_ws/build/comando_planner/test_stc_landing_noaug_ctcs','--turning-horizon'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30).returncode
  except subprocess.TimeoutExpired:rc=124
 result={'tag':tag,'overrides':over,'returncode':rc,'output':log.read_text()};results.append(result);(out/'turn-implication-gates.json').write_text(json.dumps(results,indent=2)+'\n');print(tag,rc,log.read_text().splitlines()[-2:],flush=True)
