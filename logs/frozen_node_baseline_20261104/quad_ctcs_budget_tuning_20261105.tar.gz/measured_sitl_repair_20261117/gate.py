from pathlib import Path
import os,json,subprocess
r=Path('/home/lab/mavros_ws/src/CoManDO_planner');out=Path(__file__).resolve().parent;base={}
for l in (r/'config/frozen_quad_ctcs_coarse.env').read_text().splitlines():
 if l.startswith('export '):k,v=l[7:].split('=',1);base[k]=v
trials=[('g03125',{'SZMUK_CTCS_GEOMETRIC_MARGIN':'.03125'}),('g0325',{'SZMUK_CTCS_GEOMETRIC_MARGIN':'.0325'}),('g035y2',{'SZMUK_CTCS_GEOMETRIC_MARGIN':'.035','SZMUK_CTCS_Y_SCALE':'2'}),('g035y1',{'SZMUK_CTCS_GEOMETRIC_MARGIN':'.035','SZMUK_CTCS_Y_SCALE':'1'})];results=[]
for tag,over in trials:
 profile=dict(base,**over);env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','MPC_','STC_','WALL_RH_'))};env.update(profile);env['SZMUK_TEST_REPLAY_REPEATS']='0';p=out/(tag+'-single')
 with (out/(tag+'-single.log')).open('w') as f:result=subprocess.run(['/tmp/comando-ordinary-node-rh-20261104/primary-planner/build/test_measured_root_rh','quad','matched','1',str(p),'--ctcs','--staging-initial','--audit-loop','--single-horizon'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=40)
 rec={'tag':tag,'override':over,'returncode':result.returncode,'profile':profile,'summary':json.load(open(p/'summary.json')) if (p/'summary.json').exists() else None};results.append(rec);(out/'geometry-gates.json').write_text(json.dumps(results,indent=2)+'\n');print(tag,result.returncode,flush=True)
