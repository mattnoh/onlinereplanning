import importlib.util,json,os,pathlib,subprocess
repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');root=pathlib.Path(__file__).resolve().parent;cell=root/'circle__zero__t0'
env=json.loads((cell/'planner_environment.json').read_text());os.environ.update(env)
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
scoring=module('scoring',repo/'support/scripts/mc_physical_scoring.py');converter=module('converter',repo/'support/tools/analysis/bag_to_stc_csv.py');bounds=converter.resolve_constants();row=scoring.score_cell(cell,c=bounds)
record={'result':row,'physical_bounds':bounds,'reporting_tolerances':scoring.TOL,'scope':'Original nominal physical implications over landing activation to handoff/record end, scored from flight bag using target ground truth. No optimizer tightening is substituted for physical limits.','planner_source_commit':json.loads((cell/'source.json').read_text())['planner_commit']}
(cell/'physical_audit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
import csv
with (cell/'physical_scores.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(row));w.writeheader();w.writerow(row)
bag=next(cell.glob('flight_*.bag'));subprocess.run(['python3',str(repo/'support/tools/analysis/bag_to_stc_csv.py'),str(bag),'--out',str(cell)],check=True)
