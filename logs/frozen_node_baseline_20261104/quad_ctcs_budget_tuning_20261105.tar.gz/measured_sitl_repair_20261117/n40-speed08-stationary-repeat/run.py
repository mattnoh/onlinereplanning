import argparse,hashlib,importlib.util,json,os,pathlib,signal,subprocess,time
repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');out=pathlib.Path(__file__).resolve().parent
os.environ.update(ROS_MASTER_URI='http://127.0.0.1:11341',ROS_IP='127.0.0.1',ROS_HOME=str(out/'ros-home'),ROS_LOG_DIR=str(out/'ros-log'))
for key in list(os.environ):
 if key.startswith(('SZMUK_','STC_','MPC_','WALL_RH_')):del os.environ[key]
profile={}
for name in ['config/frozen_quad_ctcs_coarse.env']:
 for line in (repo/name).read_text().splitlines():
  if line.startswith('export '):k,v=line[7:].split('=',1);profile[k]=v
os.environ.update(profile)
spec=importlib.util.spec_from_file_location('campaign',repo/'support/scripts/run_scenario_campaign.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
profile.update({'SZMUK_N': '40', 'SZMUK_MAX_ITER': '1200', 'SZMUK_W_EPS': '0.0', 'SZMUK_W_TOUCH_VEL': '0.0', 'SZMUK_R_THETA': '0.0', 'SZMUK_W_POS_XY': '0.0', 'SZMUK_W_POS_Z': '0.0', 'SZMUK_W_VEL': '0.0', 'SZMUK_RHO': '50', 'SZMUK_RHO_MUL': '10.0', 'SZMUK_REG2_MIN': '0.1', 'SZMUK_CTCS_MODE': 'step_ineq', 'SZMUK_CTCS_Y_SCALE': '5', 'SZMUK_CTCS_STEP_EPS': '1.3333333333333333e-05', 'SZMUK_LOS_TRIGGER_FLOOR': '0.0', 'SZMUK_W_LAND_SPEED': '100', 'SZMUK_W_LAND_TILT': '300000000', 'SZMUK_W_LAND_OMEGA': '1000000', 'SZMUK_W_LAND_GS': '7500', 'SZMUK_W_STC_STAGE': '100', 'SZMUK_W_STC_LOS': '200', 'SZMUK_BOUND_SCALE': '1', 'SZMUK_MU': '0.1', 'SZMUK_RH_N': '40', 'SZMUK_CTCS_TRIGGER_MARGIN': '.05', 'SZMUK_CTCS_GEOMETRIC_MARGIN': '0.02', 'SZMUK_CTCS_SPEED_MARGIN': '.08', 'SZMUK_CTCS_TILT_MARGIN_DEG': '.2', 'SZMUK_CTCS_PATH_TILT_MARGIN_DEG': '.5', 'SZMUK_CTCS_RATE_MARGIN': '.005', 'SZMUK_RHOT': '50', 'SZMUK_TERM_W_POS_XY': '100000', 'SZMUK_TERM_W_POS_Z': '10000', 'SZMUK_SOLVER_VERBOSE': '0', 'SZMUK_TH0': '0.13999999999999999', 'SZMUK_THL': '0.1', 'SZMUK_THH': '0.24', 'SZMUK_MUT': '.1', 'SZMUK_MU_MUL': '.1', 'SZMUK_FORWARD_FILTER': '1', 'SZMUK_TOL': '1e-6', 'SZMUK_QUAD_TRIG_STC': '1', 'SZMUK_STAGE_TRIGGER': 'radius', 'SZMUK_STAGE_TRIGGER_FLOOR': '0', 'SZMUK_RH_CAPTURE_LANDING_TRIGGER': '0', 'SZMUK_CTCS_LOS_MARGIN': '.045'})
os.environ.update(profile)
m.PLANNER_ENV=profile
m.MOTIONS['circle']={'target_radius':1.0,'target_omega':0.0}
owned=[];original_spawn=m.spawn

def spawn(cmd,log):
 
 if 'planner_launch.launch' in cmd:
  dump=m.sh(m.SETUP+' && rosrun mavros mavparam dump -f '+str(out/'px4.params'),timeout=40)
  (out/'param-dump.log').write_text(dump.stdout+dump.stderr)
 p=original_spawn(cmd,log);owned.append((p,pathlib.Path(log).stem));return p

def cleanup(procs=None):
 selected=[(p,name) for p,name in owned if procs is None or p in procs]
 for p,name in sorted(selected,key=lambda x:x[1]!='planner'):
  try:os.killpg(p.pid,signal.SIGINT)
  except ProcessLookupError:continue
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   p.wait(timeout=5)
 for p,name in selected:
  try:os.killpg(p.pid,signal.SIGKILL)
  except ProcessLookupError:pass
 return 'CLEAN'
m.spawn=spawn;m.teardown=cleanup
args=argparse.Namespace(reuse=False,start='original',profile=str(out/'profile.yaml'),hover_thrust=.7282821834,hover_height=2.4,settle_min_z=2.02,settle_max_z=2.6,stc_z_stage=1.8,stc_los_alt_trig=1.8,staging='offset',bearing_policy='original',shape_random=0,landing_timeout=90,solver_dir=str(repo.parent/'ALIPDDP-main'),motions='circle',levels='zero')
args.config_hash,identity=m.campaign_identity(args)
(out/'configuration.json').write_text(json.dumps(dict(args=vars(args),identity=identity,ros_master=os.environ['ROS_MASTER_URI'],planner_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),scope='One actual PX4/Gazebo measured-state CTCS RH diagnostic, original physical bounds; no solver changes'),indent=2)+'\n')
try:
 spawn(m.SETUP+' && roscore -p 11341',out/'roscore.log')
 for _ in range(50):
  p=m.sh(m.SETUP+' && rosparam list',timeout=5)
  if p.returncode==0:break
  time.sleep(.2)
 # Entry cleanup must not stop the master we just started.
 def cell_cleanup(procs=None):return 'CLEAN' if procs is None else cleanup(procs)
 m.teardown=cell_cleanup
 result=m.run_cell('circle','zero',0,str(out),args)
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
finally:cleanup()
