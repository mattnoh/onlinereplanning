exec(open('/tmp/comando-measured-plant-20261105/run.py').read().split('for name,model,profile,flags,bound in ')[0])
root=pathlib.Path('/tmp/comando-measured-plant-20261105');coarse={}
for l in pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner/config/frozen_quad_ctcs_coarse.env').read_text().splitlines():
 if l.startswith('export '):k,v=l[7:].split('=',1);coarse[k]=v
cases=[('quad-ctcs-coarse-fine','quad',coarse,['--ctcs','--staging-initial','--replay-intervals','3'],40),('quad-ctcs-coarse-disturbed','quad',coarse,['--ctcs','--staging-initial','--replay-intervals','3','--plant-acceleration-x','0.01'],40),('pointmass-node-k1-disturbed','pointmass',{},['--replay-intervals','1','--plant-acceleration-x','0.01'],60),('pointmass-ctcs-k1-disturbed','pointmass',{},['--ctcs','--replay-intervals','1','--plant-acceleration-x','0.01'],60)]
for name,model,profile,flags,bound in cases:
 out=root/name;env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','STC_','MPC_'))};env.update(profile);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',SZMUK_TEST_REPLAY_REPEATS='0');cmd=[exe,model,'fine',str(bound),str(out),'--audit-loop']+flags;t=time.time()
 with open(str(out)+'.log','w') as f:
  try:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120).returncode
  except subprocess.TimeoutExpired:rc=124
 s=json.load(open(out/'summary.json')) if (out/'summary.json').exists() else None
 r=dict(name=name,command=cmd,profile=profile,returncode=rc,wall_seconds=time.time()-t,summary=s,tail=pathlib.Path(str(out)+'.log').read_text()[-1800:]);results.append(r);(root/'cadence-results.json').write_text(json.dumps(results,indent=2));print(name,rc,s if s else r['tail'][-500:],flush=True)
