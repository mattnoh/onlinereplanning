import os,pathlib,json,subprocess,time
root=pathlib.Path('/tmp/comando-measured-plant-20261105');saved=json.load(open('/home/lab/mavros_ws/src/CoManDO_planner/logs/frozen_node_baseline_20261104/quad_ctcs_rh_from_sh_20261105.json'))
quad=saved['budget_tuning']['validation']['selected-rh']['profile'];node=saved['validation']['final-quad-node']['profile'];exe='/tmp/comando-ordinary-node-rh-20261104/primary-planner/build/test_measured_root_rh';results=[]
for name,model,profile,flags,bound in [('quad-node','quad',node,[],40),('quad-ctcs','quad',quad,['--ctcs','--staging-initial'],40),('pointmass-node','pointmass',{},[],15),('pointmass-ctcs','pointmass',{},['--ctcs'],15)]:
 out=root/(name+'-disturbed');env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','STC_','MPC_'))};env.update(profile);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',SZMUK_TEST_REPLAY_REPEATS='0')
 cmd=[exe,model,'fine',str(bound),str(out),'--audit-loop','--plant-acceleration-x','0.01']+flags;t=time.time()
 with open(str(out)+'.log','w') as f:
  try:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120).returncode
  except subprocess.TimeoutExpired:rc=124
 s=json.load(open(out/'summary.json')) if (out/'summary.json').exists() else None
 r=dict(name=name,command=cmd,profile=profile,returncode=rc,wall_seconds=time.time()-t,summary=s,tail=pathlib.Path(str(out)+'.log').read_text()[-1800:]);results.append(r);(root/'disturbed-results.json').write_text(json.dumps(results,indent=2));print(name,rc,s if s else r['tail'],flush=True)
