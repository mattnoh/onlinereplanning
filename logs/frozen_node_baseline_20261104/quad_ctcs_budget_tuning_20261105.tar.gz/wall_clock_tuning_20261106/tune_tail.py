import json,os,pathlib,subprocess,time
repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');root=pathlib.Path('/tmp/comando-wall-clock-rh-20261106/tuning-full-audit');build=pathlib.Path('/tmp/comando-ordinary-node-rh-20261104/primary-planner/build');base={}
for l in (repo/'config/frozen_quad_ctcs.env').read_text().splitlines():
 if l.startswith('export '):k,v=l[7:].split('=',1);base[k]=v
base['SZMUK_TERM_W_POS_XY']='200000'
base['SZMUK_CTCS_Y_SCALE']='2'
base.update(SZMUK_CTCS_SUBSTEPS='3',WALL_RH_INITIAL_LEAD='3.0',WALL_RH_GUARD='.5')
trials=[('m3-los5000',{'SZMUK_W_STC_LOS':'5000'}),('m3-los50000',{'SZMUK_W_STC_LOS':'50000'}),('m3-termxy5',{'SZMUK_TERM_W_POS_XY':'500000'}),('m3-termz10',{'SZMUK_TERM_W_POS_Z':'100000'}),('m3-stagexy1',{'SZMUK_W_POS_XY':'1'}),('m3-stagexy10',{'SZMUK_W_POS_XY':'10'}),('m3-stagexy100',{'SZMUK_W_POS_XY':'100'}),('m3-termxy5-los5000',{'SZMUK_TERM_W_POS_XY':'500000','SZMUK_W_STC_LOS':'5000'})]
results=json.load(open(root/'results.json'))
def run(cmd,env,log,timeout=60):
 start=time.time()
 with open(log,'w') as f:
  try:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:rc=124
 return rc,time.time()-start
for tag,override in trials:
 profile=dict(base,**override);env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','STC_','MPC_','WALL_RH_'))};env.update(profile);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',SZMUK_TEST_REPLAY_REPEATS='0')
 single=root/(tag+'-single');cmd=[str(build/'test_measured_root_rh'),'quad','matched','1',str(single),'--ctcs','--staging-initial','--audit-loop','--single-horizon'];rc,seconds=run(cmd,env,str(single)+'.log');summary=json.load(open(single/'summary.json')) if (single/'summary.json').exists() else None
 rec=dict(tag=tag,override=override,profile=profile,single=dict(returncode=rc,wall_seconds=seconds,summary=summary),runs=[]);results.append(rec)
 (root/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(tag,'single',rc,summary.get('planned_physical_stc_excess') if summary else None,flush=True)
 if rc!=0:continue
 for rep in [0,1]:
  out=root/(tag+'-r'+str(rep));cmd=[str(build/'test_wall_clock_rh'),'quad','ctcs','20',str(out),'delay-compensated'];rc,seconds=run(cmd,env,str(out)+'.log');summary=json.load(open(out/'summary.json')) if (out/'summary.json').exists() else None
  audit_path=root/(out.name+'-audit.json');audit=None;arc=None
  if rc==0:
   p=subprocess.run(['python3',str(repo/'support/tools/analysis/audit_wall_clock.py'),str(out),'--binary',str(build/'test_wall_clock_rh'),'--output',str(audit_path)],capture_output=True,text=True);arc=p.returncode
   if audit_path.exists():audit=json.load(open(audit_path))
  rec['runs'].append(dict(name=out.name,returncode=rc,wall_seconds=seconds,summary=summary,audit_returncode=arc,audit=audit));(root/'results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(tag,'repeat',rep,'runtime',rc,'audit',arc,{k:audit[k] for k in ['planned_physical_STC_or_active_obstacle_excess','executed_physical_STC_or_active_obstacle_excess','native_budget_ratio','planned_dense_budget_ratio','executed_budget_ratio']} if audit else None,flush=True)
  if rc!=0 or arc!=0:break
