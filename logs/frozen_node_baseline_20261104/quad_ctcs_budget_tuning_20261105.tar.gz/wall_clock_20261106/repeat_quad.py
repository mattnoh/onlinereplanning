import os,pathlib,json,subprocess,time
root=pathlib.Path('/tmp/comando-wall-clock-rh-20261106/repeat-quad');root.mkdir(exist_ok=True);repo=pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner');profiles={}
for tag,path in [('quad-ctcs',repo/'config/frozen_quad_ctcs.env')]:
 p={}
 for l in path.read_text().splitlines():
  if l.startswith('export '):k,v=l[7:].split('=',1);p[k]=v
 profiles[tag]=p
profiles['quad-node']={'SZMUK_RH_N':'40','SZMUK_THH':'.16','SZMUK_MAX_ITER':'120'}
exe='/tmp/comando-ordinary-node-rh-20261104/primary-planner/build/test_wall_clock_rh';results=[]
for model,mode,seconds in [('quad','node',20),('quad','ctcs',20)]:
 name=model+'-'+mode;out=root/name;env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','STC_','MPC_'))};profile=profiles.get(name,{});env.update(profile);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
 cmd=[exe,model,mode,str(seconds),str(out),'delay-compensated'];start=time.time()
 with open(str(out)+'.log','w') as f:
  try:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=seconds+30).returncode
  except subprocess.TimeoutExpired:rc=124
 s=json.load(open(out/'summary.json')) if (out/'summary.json').exists() else None
 r=dict(name=name,command=cmd,profile=profile,returncode=rc,wall_seconds=time.time()-start,summary=s,tail=pathlib.Path(str(out)+'.log').read_text()[-1200:]);results.append(r);(root/'results.json').write_text(json.dumps(results,indent=2));print(name,rc,s if s else r['tail'],flush=True)
