import pathlib,json,numpy as np
root=pathlib.Path('/tmp/comando-wall-clock-rh-20261106');results={}
centers=np.array([[-6.5,-3],[-1.8,3.5],[.5,-3.5],[2.7,1.5],[6.2,-3.]])
for folder in ['shift-only-contract','repeat-quad','final']:
 for case in (root/folder).glob('*/summary.json'):
  p=case.parent;summary=json.load(open(case));solves=[json.loads(l) for l in (p/'solves.jsonl').read_text().splitlines() if json.loads(l)['accepted']];data=np.genfromtxt(p/'plant.csv',delimiter=',',names=True)
  node_times=[]
  for i,s in enumerate(solves):
   end=solves[i+1]['activation_epoch'] if i+1<len(solves) else float(data['t'][-1]);node_times += [t for t in s['node_times'] if s['activation_epoch']-1e-9<=t<=min(end,data['t'][-1])+1e-9]
  times=np.unique(np.round(node_times,9));audit=dict(unique_executed_node_times=len(times),evaluated_node_samples=len(node_times))
  if summary['model']=='pointmass':
   positions=np.column_stack([np.interp(times,data['t'],data[k]) for k in ['x0','x1']]);g=1-np.linalg.norm((positions[:,None,:]-centers[None,:,:])*np.array([2.4,.4]),axis=2);audit['executed_node_obstacle_excess']=max(0.,float(g.max()))
  else:
   z=np.interp(times,data['t'],data['x2']);v=np.column_stack([np.interp(times,data['t'],data[k]) for k in ['x3','x4','x5']]);audit['executed_node_speed_floor_excess']=max(0.,float((-z).max()),float((np.linalg.norm(v,axis=1)-3).max()))
  assert summary['runtime_complete'] and summary['plant_steps_while_solving']>0 and summary['stale_samples']==0
  assert summary['native_violation']<=1e-6
  assert summary['physical_STC_excess']<=1e-6 and summary['hard_constraint_excess']<=1e-6
  if p.name=='pointmass-ctcs':assert summary['obstacle_excess_diagnostic']==0
  if p.name=='pointmass-node':assert audit['executed_node_obstacle_excess']<=1e-6
  (p/'executed-node-audit.json').write_text(json.dumps(audit,indent=2)+'\n');results[folder+'/'+p.name]=dict(summary=summary,node_audit=audit)
def parse(path):
 lines=path.read_text().splitlines();d={}
 for i,line in enumerate(lines):
  a=line.split()
  if a and a[0] in ['returned_X','returned_U']:d[a[0]]=np.array([[float(v) for v in l.split()[1:]] for l in lines[i+1:i+1+int(a[1])]])
 return d
comparisons={}
for name,old in [('quad-node','/tmp/comando-fixed-dt-20261105/quad-rh-from-sh/final-quad-node'),('quad-ctcs','/tmp/comando-ctcs-budget-20261105/selected-rh'),('pointmass-node','/tmp/comando-fixed-dt-20261105/quad-rh-from-sh/final-pointmass-node'),('pointmass-ctcs','/tmp/comando-fixed-dt-20261105/quad-rh-from-sh/final-pointmass-ctcs')]:
 p=root/'frozen-regression'/name
 if not (p/'summary.json').exists():continue
 new=sorted(p.glob('request-*.txt'));maximum=0.
 for q in new:
  a=parse(q);b=parse(pathlib.Path(old)/q.name)
  for k in a:maximum=max(maximum,float(abs(a[k]-b[k]).max()))
 assert maximum==0.;comparisons[name]=dict(requests_compared=len(new),max_returned_state_control_difference=maximum)
(root/'audits.json').write_text(json.dumps(dict(wall_clock=results,frozen_returned_trajectories=comparisons),indent=2)+'\n')
print(json.dumps(dict(cases=len(results),node_audits={k:v['node_audit'] for k,v in results.items()},frozen=comparisons),indent=2))
