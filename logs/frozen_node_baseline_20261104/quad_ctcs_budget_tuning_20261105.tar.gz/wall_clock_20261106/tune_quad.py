import os,json,pathlib,subprocess,time
root=pathlib.Path('/tmp/comando-wall-clock-rh-20261106');profile={}
for l in pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner/config/frozen_quad_ctcs.env').read_text().splitlines():
 if l.startswith('export '):k,v=l[7:].split('=',1);profile[k]=v
exe='/tmp/comando-ordinary-node-rh-20261104/primary-planner/build/test_wall_clock_rh';results=[]
for tag,overrides in [('eps2e-5',{'SZMUK_CTCS_STEP_EPS':'2e-5'}),('eps5e-6',{'SZMUK_CTCS_STEP_EPS':'5e-6'}),('y1',{'SZMUK_CTCS_Y_SCALE':'1'}),('rho50',{'SZMUK_RHO':'50','SZMUK_RHOT':'50'})]:
 for repeat in [0,1]:
  env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','STC_','MPC_'))};env.update(profile);env.update(overrides);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');out=root/f'quad-tune-{tag}-r{repeat}';cmd=[exe,'quad','ctcs','20',str(out),'delay-compensated'];start=time.time()
  with open(str(out)+'.log','w') as f:
   try:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=50).returncode
   except subprocess.TimeoutExpired:rc=124
  s=json.load(open(out/'summary.json')) if (out/'summary.json').exists() else None
  r=dict(tag=tag,repeat=repeat,profile=env,command=cmd,returncode=rc,summary=s);r['profile']={k:v for k,v in env.items() if k.startswith('SZMUK_')};results.append(r);(root/'quad-tuning.json').write_text(json.dumps(results,indent=2));print(tag,repeat,rc,s,flush=True)
  if rc!=0 or s['physical_STC_excess']>1e-6 or s['hard_constraint_excess']>1e-6:break
 else:break
