import os,json,pathlib,subprocess,time
root=pathlib.Path('/tmp/comando-ctcs-budget-20261105');profile={}
for line in pathlib.Path('/home/lab/mavros_ws/src/CoManDO_planner/config/frozen_quad_ctcs.env').read_text().splitlines():
 if line.startswith('export '):k,v=line[7:].split('=',1);profile[k]=v
base={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','STC_','MPC_'))};base.update(profile)
# Match the reproducible historical harness options, with no changed checker.
base.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',SZMUK_TEST_REPLAY_REPEATS='0')
exe='/tmp/comando-ordinary-node-rh-20261104/primary-planner/build/test_measured_root_rh';results={}
for name,cycles,flags in [('selected-single',1,['--single-horizon']),('selected-rh',40,[])]:
 out=root/name;cmd=[exe,'quad','matched',str(cycles),str(out),'--audit-loop','--ctcs','--staging-initial']+flags;t=time.time()
 with open(str(out)+'.log','w') as f:rc=subprocess.run(cmd,env=base,stdout=f,stderr=subprocess.STDOUT,timeout=120).returncode
 summary=json.load(open(out/'summary.json')) if (out/'summary.json').exists() else {}
 results[name]=dict(command=cmd,returncode=rc,seconds=time.time()-t,profile=profile,summary=summary)
 (root/'selected-validation.json').write_text(json.dumps(results,indent=2));print(name,rc,summary,flush=True)
