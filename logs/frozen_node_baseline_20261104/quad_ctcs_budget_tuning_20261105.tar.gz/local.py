import os,json,subprocess,pathlib,time
root=pathlib.Path('/tmp/comando-ctcs-budget-20261105')
base=json.load(open('/tmp/comando-fixed-dt-20261105/quad-rh-from-sh/final-profile.json'))
binary='/tmp/comando-ordinary-node-rh-20261104/primary-planner/build/test_measured_root_rh';results=[]
trials=[('eps9e-6-scale.5',{'SZMUK_CTCS_STEP_EPS':'9e-6'}),('eps1.1e-5-scale.5',{'SZMUK_CTCS_STEP_EPS':'1.1e-5'}),('eps1.5e-5-scale.5',{'SZMUK_CTCS_STEP_EPS':'1.5e-5'}),('eps7.5e-6-scale.5',{'SZMUK_CTCS_STEP_EPS':'7.5e-6'}),('scale.45',{'SZMUK_CTCS_Y_SCALE':'.45'}),('scale.55',{'SZMUK_CTCS_Y_SCALE':'.55'})]
for name,override in trials:
 out=root/name;env={k:v for k,v in os.environ.items() if not k.startswith(('SZMUK_','STC_','MPC_'))};env.update(base);env['SZMUK_CTCS_Y_SCALE']='0.5';env.update(override)
 cmd=[binary,'quad','matched','40',str(out),'--audit-loop','--ctcs','--staging-initial'];t=time.time()
 with open(str(out)+'.log','w') as f:
  try:rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120).returncode
  except subprocess.TimeoutExpired:rc=124
 summary=json.load(open(out/'summary.json')) if (out/'summary.json').exists() else {}
 results.append(dict(name=name,override=override,rc=rc,seconds=time.time()-t,summary=summary));(root/'local-results.json').write_text(json.dumps(results,indent=2))
 print(name,rc,{k:summary.get(k) for k in ['accepted','reached','native_ctcs_ratio','planned_ctcs_ratio','executed_ctcs_ratio','physical_stc_excess','planned_physical_stc_excess']},flush=True)
